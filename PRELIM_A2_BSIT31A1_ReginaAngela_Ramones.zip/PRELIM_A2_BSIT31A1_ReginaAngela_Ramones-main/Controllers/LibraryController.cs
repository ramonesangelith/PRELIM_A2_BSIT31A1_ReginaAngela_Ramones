using Library.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace Library.Controllers
{
    public class LibraryController : Controller
    {
        // Simulated in-memory "database"
        private static List<Book> Books = new();
        private static List<Author> Authors = new();
        private static List<User> Users = new();
        private static LibraryController Library = new() { Id = 1, Location = "Main Campus" };

        public int Id { get; private set; }
        public string Location { get; private set; }

        public IActionResult Index()
        {
            return RedirectToAction("ViewAllBooks");
        }

        public IActionResult ViewAllBooks()
        {
            return View(Books); // Requires Books.cshtml if you later add views
        }

        public IActionResult AddBook()
        {
            return View(); // Show add form
        }

        [HttpPost]
        public IActionResult AddBook(Book book, LibraryController Library)
        {
            var author = Authors.FirstOrDefault(a => a.Id == book.AuthorId);
            if (author == null)
            {
                return NotFound("Author not found.");
            }

            book.Author = author;
            book.Id = Books.Count + 1;
            Books.Add(book);
            LibraryController.Books.Add(book);

            return RedirectToAction("ViewAllBooks");
        }

        public IActionResult BorrowBook(int bookId, int userId)
        {
            var book = Books.FirstOrDefault(b => b.Id == bookId && !b.IsBorrowed);
            var user = Users.FirstOrDefault(u => u.Id == userId);

            if (book == null || user == null)
                return NotFound();

            book.IsBorrowed = true;
            user.BorrowedBooks.Add(book);

            return RedirectToAction("ViewAllBooks");
        }

        public IActionResult ReturnBook(int bookId, int userId)
        {
            var book = Books.FirstOrDefault(b => b.Id == bookId && b.IsBorrowed);
            var user = Users.FirstOrDefault(u => u.Id == userId);

            if (book == null || user == null)
                return NotFound();

            book.IsBorrowed = false;
            user.BorrowedBooks.Remove(book);

            return RedirectToAction("ViewAllBooks");
        }
    }
}
